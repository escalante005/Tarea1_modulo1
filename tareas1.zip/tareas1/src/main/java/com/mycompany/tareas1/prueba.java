/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tareas1;
import java.util.Scanner;

/**
 *
 * @author emerson joya
 */
public class prueba {
    
    
public class EntradaDatos {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Ingresa tu nombre:");
            String nombre = scanner.nextLine();
            
            System.out.println("Ingresa tu edad:");
            int edad = scanner.nextInt();
            
            // Limpiar el buffer de entrada
            scanner.nextLine();
            
            System.out.println("Ingresa tu ciudad:");
            String ciudad = scanner.nextLine();
            
            System.out.println("Hola " + nombre + ", tienes " + edad + " años y vives en " + ciudad + ".");
        }
    }
}

    
}
