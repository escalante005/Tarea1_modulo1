/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tareas1;

/**
 *
 * @author emerson joya
 */


public class DatosCompaneros {
    public static void main(String[] args) {
        String[][] datosCompaneros = {
            {"Rodolfo", "Aguirre", "Mecatrónica", "Cofisa"},
            {"Emerson", "Escalante", "Industrial", "Banco Occidente"},
            {"Edwin", "Joya", "Electrónica", "Herco"},
            {"Dora", "Martínez", "Computación", "Banco Atlántida"},
            {"Desiree", "Carrasco", "Administración", "IMSA"}
        };

        imprimirDatos(datosCompaneros);
    }

    public static void imprimirDatos(String[][] datos) {
        System.out.println("Datos de los compañeros de clase:");
        System.out.println("--------------------------------------");

        for (String[] companero : datos) {
            System.out.println("Nombre:          " + companero[0]);
            System.out.println("Apellido:        " + companero[1]);
            System.out.println("Carrera:         " + companero[2]);
            System.out.println("Lugar de Trabajo:" + companero[3]);
            System.out.println("--------------------------------------");
        }
    }
}

