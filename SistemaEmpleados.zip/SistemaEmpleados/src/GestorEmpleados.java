
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emerson joya
 */


public class GestorEmpleados {
    private final List<Empleado> listaEmpleados;

    public GestorEmpleados() {
        listaEmpleados = new ArrayList<>();
    }

    public void agregarEmpleado(Empleado empleado) {
        listaEmpleados.add(empleado);
        System.out.println("Empleado agregado con éxito.");
    }

    public void mostrarEmpleados() {
    if (listaEmpleados.isEmpty()) {
        System.out.println("No hay empleados registrados.");
    } else {
        System.out.println("Lista de empleados:");
        listaEmpleados.forEach(e -> { 
            e.mostrarInformacion();
        });
        } // <- Cierre correcto del for
    } // <- Cierre correcto del else
} // <- Cierre correcto del método

