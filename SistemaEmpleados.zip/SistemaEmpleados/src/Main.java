
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emerson joya
 */


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GestorEmpleados gestor = new GestorEmpleados();

        while (true) {
            System.out.println("\n--- Menú Gestión de Empleados ---");
            System.out.println("1. Agregar Empleado");
            System.out.println("2. Mostrar Empleados");
            System.out.println("3. Salir");
            System.out.print("Elige una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir la línea nueva después de nextInt()

            switch (opcion) {
                case 1 -> {
                    System.out.print("Nombre del empleado: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Edad del empleado: ");
                    int edad = scanner.nextInt();
                    System.out.print("Salario del empleado: ");
                    double salario = scanner.nextDouble();
                    scanner.nextLine(); // Consumir la línea nueva después de nextDouble()
                    Empleado nuevoEmpleado = new Empleado(nombre, edad, salario);
                    gestor.agregarEmpleado(nuevoEmpleado);
                }

                case 2 -> gestor.mostrarEmpleados();

                case 3 -> {
                    System.out.println("Saliendo del programa...");
                    scanner.close();
                    return;
                }

                default -> System.out.println("Opción no válida. Intenta de nuevo.");
            }
        }
    }
}
  

