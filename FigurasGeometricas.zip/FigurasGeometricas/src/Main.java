
import formas.Circulo;
import formas.Forma;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emerson joya
 */
public class Main {
    public static void main(String[] args) {
        Forma[] formas;
        formas = new Forma[] {
            new Circulo("Rojo", 5.0),
            new Linea("Azul", 10.0),
            new Triangulo("Verde", 60),
            new Cuadrado("Amarillo", 25)
        };

        for (Forma forma : formas) {
            forma.dibujar();
        }
    }
}

