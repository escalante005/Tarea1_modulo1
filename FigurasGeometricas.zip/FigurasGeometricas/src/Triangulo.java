
import formas.Forma;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emerson joya
 */
public class Triangulo extends Forma {
    private final double angulo;

    public Triangulo(String color, double angulo) {
        super(color);
        this.angulo = angulo;
    }

    public double calcularArea() {
        return (Math.sin(Math.toRadians(angulo)));  // Área simbólica
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un triángulo");
    }
}
