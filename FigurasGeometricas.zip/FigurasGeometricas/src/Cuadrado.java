
import formas.Forma;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emerson joya
 */
public class Cuadrado extends Forma {
    private final double area;

    public Cuadrado(String color, double area) {
        super(color);
        this.area = area;
    }

    public double calcularArea() {
        return area;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un cuadrado");
    }
}

