/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emerson joya
 */
package formas;  // Asegúrate de que todas las clases estén en el mismo paquete

public abstract class Forma {
    protected String color;

    public Forma(String color) {
        this.color = color;
    }

    public void establecerColor(String color) {
        this.color = color;
    }

    public abstract void dibujar();
}

