/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emerson joya
 */
package formas;  // Asegúrate de que todas las clases tengan el mismo paquete

public class Circulo extends Forma {
    private final double radio;

    // Constructor corregido
    public Circulo(String color, double radio) {
        super(color);  // Llamamos correctamente al constructor de Forma
        this.radio = radio;
    }

    public double calcularRadio() {
        return radio;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un círculo");
    }
}

